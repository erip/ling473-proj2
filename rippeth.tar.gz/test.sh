#!/usr/bin/env bash

source setup_env.sh

run_test
